echo "<module>";
echo "<name><![CDATA[top]]></name>";
echo "<type><![CDATA[generic_data_string]]></type>";
echo "<data><![CDATA["
top -b -n 1
echo "]]></data>"
echo "</module>"

